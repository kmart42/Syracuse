#include <xinu.h>

void runforever(){
	kprintf("%d\n", getpid());
	//while(1);
}
